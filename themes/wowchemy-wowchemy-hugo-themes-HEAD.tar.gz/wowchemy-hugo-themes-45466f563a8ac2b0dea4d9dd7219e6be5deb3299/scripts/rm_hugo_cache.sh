#!/usr/bin/env bash

# Clear Hugo's cache on MacOS (assumes default path)
sudo rm -rf $TMPDIR/hugo_cache/
